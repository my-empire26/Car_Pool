import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  title = 'TrailProject';

  ngOnInit() {
  }


  login_Form: FormGroup;
  email = new FormControl("", [Validators.required, Validators.pattern(''),]);
  password = new FormControl("", [Validators.required, Validators.maxLength(8), Validators.minLength(4)]);

  constructor(fb: FormBuilder) {
    this.login_Form = fb.group({
      "email": this.email,
      "password": this.password

    });
  }

  doLogin(values: any): void {
    if (this.login_Form.valid) {
      console.log(values);
    }
  }

  checkUser() {
    if (this.email.value == 'admin@gmail.com' && this.password.value == 'admin123') {
      console.log("login successful");
      window.location.assign("/admindashboard");
    }
    else {
      console.log("login failed");
    }
  }

}
