import { Component, OnInit } from '@angular/core';
import {Location} from '../LocationModel/Location-model';
import { LocationService } from '../location.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-location-component',
  templateUrl: './location-component.component.html',
  styleUrls: ['./location-component.component.css']
})
export class LocationComponentComponent implements OnInit {
  loc:LocationService;
  locationlist:any;
  sourcelist:any;
  destinationlist:any;
  constructor(public locservice:LocationService) 
  { 

  }

  ngOnInit() 
  {

  }

  public Insert(value:Location)
  {
    this.locservice.addLocation(value);
  }
  public Update(value:Location)
  {
    this.locservice.updateLocation(value);
  }
  public ShowLocationList()
  {
     this.locservice.showLocation().subscribe((data)=>{this.locationlist=data});
  }
  public ShowSourceList()
  {
     this.locservice.showSource().subscribe((data)=>{this.sourcelist=data});
  }
  public ShowDestinationList()
  {
     this.locservice.showDestination().subscribe((data)=>{this.destinationlist=data});
  }
  
}
