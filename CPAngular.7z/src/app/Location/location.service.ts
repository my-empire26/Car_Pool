import { Injectable } from '@angular/core';
import {Location} from '../Location/LocationModel/Location-model';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LocationService {
  Locs;
  locdata:Location;
  constructor(public http:HttpClient) { }
  addLocation(locationdata:Location)
  {
    console.log(locationdata.LocationId);
    console.log(locationdata.Source);
    console.log(locationdata.Destination);
    console.log(locationdata.Distance);
    console.log(locationdata.RateId);
    this.locdata=new Location();
    this.locdata.LocationId=locationdata.LocationId;
    this.locdata.Source=locationdata.Source;
    this.locdata.Destination=locationdata.Destination;
    this.locdata.Distance=locationdata.Distance;
    this.locdata.RateId=locationdata.RateId;

    this.http.post('http://localhost:61786/api/Location',this.locdata)
    .subscribe(res=>{this.Locs=res});
    console.log('going to server');

  }
  updateLocation(locationdata:Location)
  {
    console.log(locationdata.LocationId);
    console.log(locationdata.Source);
    console.log(locationdata.Destination);
    console.log(locationdata.Distance);
    console.log(locationdata.RateId);
    this.locdata=new Location();
    this.locdata.LocationId=locationdata.LocationId;
    this.locdata.Source=locationdata.Source;
    this.locdata.Destination=locationdata.Destination;
    this.locdata.Distance=locationdata.Distance;
    this.locdata.RateId=locationdata.RateId;

    this.http.put('http://localhost:61786/api/Location/'+this.locdata.LocationId,this.locdata)
    .subscribe(res=>(this.Locs=res));
    console.log('going to server');
  }

  showLocation()
  {
    return this.http.get('http://localhost:61786/api/Location');
  }

  showSource()
  {
    return this.http.get('http://localhost:61786/api/Location/getsource');
  }
  showDestination()
  {
    return this.http.get('http://localhost:61786/api/Location/getdestination');
  }



}
