export class Location
{
    LocationId:string;
    Source:string;
    Destination:string;
    Distance:number;
    RateId:string;
}