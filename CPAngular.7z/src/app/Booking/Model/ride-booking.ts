export class RideBooking
{
    RideId:number;
    ProfileId:number;
    DriverRating:number;
    RiderRating:number;
    PassengerId:number;
    LocationId:string;
    PaidAmount:number;
    RideStart:any;
}