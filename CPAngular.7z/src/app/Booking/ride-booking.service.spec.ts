import { TestBed } from '@angular/core/testing';

import { RideBookingService } from './ride-booking.service';

describe('RideBookingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RideBookingService = TestBed.get(RideBookingService);
    expect(service).toBeTruthy();
  });
});
