import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { retry, catchError } from 'rxjs/operators';
import {RideBooking} from '../Booking/Model/ride-booking';

@Injectable({
  providedIn: 'root'
})
export class RideBookingService {
  bookings;
  ridebooking:RideBooking;
  constructor(public http:HttpClient) { }

  InsertRide(bookingdata:RideBooking)
  {
    console.log(bookingdata.RideId);
    console.log(bookingdata.ProfileId);
    console.log(bookingdata.DriverRating);
    console.log(bookingdata.RiderRating);
    console.log(bookingdata.PassengerId);
    console.log(bookingdata.LocationId);
    

    this.ridebooking=new RideBooking();
    this.ridebooking.RideId=bookingdata.RideId;
    this.ridebooking.ProfileId=bookingdata.ProfileId;
    this.ridebooking.DriverRating=bookingdata.DriverRating;
    this.ridebooking.RiderRating=bookingdata.RiderRating;
    this.ridebooking.PassengerId=bookingdata.PassengerId;
    this.ridebooking.LocationId=bookingdata.LocationId;


    this.http.post('http://localhost:61786/api/RideHistory',this.ridebooking)
    .subscribe(res=>{this.bookings=res});
    console.log('going to server');
  }
}
