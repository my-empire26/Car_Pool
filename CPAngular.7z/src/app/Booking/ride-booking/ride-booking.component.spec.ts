import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RideBookingComponent } from './ride-booking.component';

describe('RideBookingComponent', () => {
  let component: RideBookingComponent;
  let fixture: ComponentFixture<RideBookingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RideBookingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RideBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
