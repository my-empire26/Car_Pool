import { Component, OnInit } from '@angular/core';
import {RideBooking} from '../Model/ride-booking';
import {RideBookingService} from '../ride-booking.service';

@Component({
  selector: 'app-ride-booking',
  templateUrl: './ride-booking.component.html',
  styleUrls: ['./ride-booking.component.css']
})
export class RideBookingComponent implements OnInit {
  ridebooking:RideBooking;

  constructor(public bookingService:RideBookingService) { }

  ngOnInit() {
  }

  public RideBookingInsert(value:RideBooking)
  {
    this.bookingService.InsertRide(value);
  }

}
