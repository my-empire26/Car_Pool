import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserProfileComponentComponent } from './UserProfile/user-profile-component/user-profile-component.component';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { RateCardComponentComponent } from './RateCard/rate-card-component/rate-card-component.component';
import { LocationComponentComponent } from './Location/location-component/location-component.component';
import { LoginComponent } from './UserLogin/login/login.component';
import { WalletComponent } from './UserWallet/wallet/wallet.component';
import { RegisterUserComponent } from './UserRegistration/register-user/register-user.component';
// import { RouterModule } from '@angular/router';  
@NgModule({
  declarations: [
    AppComponent,
    UserProfileComponentComponent,
    RateCardComponentComponent,
    LocationComponentComponent,
    LoginComponent,
    WalletComponent,
    RegisterUserComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,FormsModule,AppRoutingModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
