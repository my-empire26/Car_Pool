import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UserProfile} from '../UserProfile/UserProfileModel/UserProfile';
import { from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RegisterUserService {

  Users;
  udata:UserProfile;
  ProfileId:number;
  constructor(public http:HttpClient) 
  { 

  }
  
  addUserProfile(userdata:UserProfile)
  {
    console.log(userdata.ProfileName);
    console.log(userdata.Password);
    console.log(userdata.Gender);
    console.log(userdata.ProfileAvatar);
    console.log(userdata.ContactNumber);
    console.log(userdata.EmailId);
    console.log(userdata.CarRTONumber);
    console.log(userdata.CarName);
    console.log(userdata.CarType);
    console.log(userdata.DrivingLicenseNumber);
    this.udata=new UserProfile();
    this.udata.ProfileName=userdata.ProfileName;
    this.udata.Password=userdata.Password;
    this.udata.Gender=userdata.Gender;
    this.udata.ProfileAvatar=userdata.ProfileAvatar;
    this.udata.ContactNumber=userdata.ContactNumber;
    this.udata.EmailId=userdata.EmailId;
    this.udata.CarRTONumber=userdata.CarRTONumber;
    this.udata.CarName=userdata.CarName;
    this.udata.CarType=userdata.CarType;
    this.udata.DrivingLicenseNumber=userdata.DrivingLicenseNumber;
    
    this.http.post('http://localhost:61786/api/UserProfile',this.udata)
    .subscribe(res=>{this.Users});
    //console.log('Dending Data to server');

  }
}
