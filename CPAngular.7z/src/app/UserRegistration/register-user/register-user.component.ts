import { Component, OnInit } from '@angular/core';
import {RegisterUserService} from '../register-user.service';
import {UserProfile} from '../../UserProfile/UserProfileModel/UserProfile';
import {Router} from '@angular/router';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {
  user:UserProfile;
  profiletype:any;
  constructor(public UserServiceService:RegisterUserService) { }

  ngOnInit() {
  }
  public Insert(value:UserProfile)
  {
    this.UserServiceService.addUserProfile(value);
    alert("Account Registered");
  }
}
