export class UserProfile
{
    ProfileId:number;
    ProfileName:String;
    Password:String;
    Gender:String;
    ProfileAvatar:any;
    ContactNumber:number;
    EmailId:string;
    CarRTONumber:String;
    CarName:String;
    CarType:String;
    DrivingLicenseNumber:String;
}