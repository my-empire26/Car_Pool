import { Component, OnInit } from '@angular/core';
import {UserServiceService} from '../user-service.service';
import {UserProfile} from '../UserProfileModel/UserProfile';
import {Router} from '@angular/router';



@Component({
  selector: 'app-user-profile-component',
  templateUrl: './user-profile-component.component.html',
  styleUrls: ['./user-profile-component.component.css']
})
export class UserProfileComponentComponent implements OnInit {
  user:UserProfile;
  profiletype:any;
  


  constructor(public UserServiceService:UserServiceService) { }

  ngOnInit() 
  {
    
    this.user=new UserProfile();
  //   sessionStorage.setItem('username','prasun mukherjee');
  //   localStorage.setItem('username','prasun mukherjee');
  // console.log(localStorage.getItem('username'));
  // console.log( sessionStorage.getItem('username'));
  }
  public Insert(value:UserProfile)
  {
    this.UserServiceService.addUserProfile(value);
  }
  public OnDelete(userform:UserProfile)
  {
    console.log(userform.ProfileId);
    this.UserServiceService.deleteUserProfile(userform);
  }

  public OnUpdate(value:UserProfile)
  {
    this.UserServiceService.updateUserProfile(value);
  }

 

}
