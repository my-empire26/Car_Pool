import { Component, OnInit } from '@angular/core';
import {Wallet} from '../Models/wallet-model';
import {WalletService} from '../wallet.service';

@Component({
  selector: 'app-wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.css']
})
export class WalletComponent implements OnInit {
  uw:Wallet;
  uwlist:any;
  constructor(public walletservice:WalletService) { }

  ngOnInit() {
  }

  public OnFormSubmit(ProfileId: number) {
    this.uwlist = this.walletservice.getWalletById(ProfileId).subscribe((data) => { this.uwlist = data });
  }

}
