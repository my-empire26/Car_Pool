import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Wallet} from '../UserWallet/Models/wallet-model';

@Injectable({
  providedIn: 'root'
})
export class WalletService {
  Uwts;
  wdata:Wallet;
  constructor(public http:HttpClient) { }

  getWalletById(ProgileId:number)
  {
       
    
   return this.http.get('http://localhost:61786/api/UserWallet'+ProgileId);
  }

}
