export class Wallet
{
    WalletId:number;
    ProfileId:number;
    CurrentBalance:number;
}