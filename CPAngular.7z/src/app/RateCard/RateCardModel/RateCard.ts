export class RateCard
{
    RateId:string;
    KmStart:number;
    KmEnd:number;
    RideRate:any;
}