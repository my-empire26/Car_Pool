import { TestBed } from '@angular/core/testing';

import { RateCardServiceService } from './rate-card-service.service';

describe('RateCardServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RateCardServiceService = TestBed.get(RateCardServiceService);
    expect(service).toBeTruthy();
  });
});
