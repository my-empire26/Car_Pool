import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RateCardComponentComponent } from './rate-card-component.component';

describe('RateCardComponentComponent', () => {
  let component: RateCardComponentComponent;
  let fixture: ComponentFixture<RateCardComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RateCardComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RateCardComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
