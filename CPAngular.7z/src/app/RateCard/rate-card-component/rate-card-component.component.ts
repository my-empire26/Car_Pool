import { Component, OnInit } from '@angular/core';
import { RateCard } from '../RateCardModel/RateCard';
import { RateCardServiceService } from '../rate-card-service.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-rate-card-component',
  templateUrl: './rate-card-component.component.html',
  styleUrls: ['./rate-card-component.component.css']
})
export class RateCardComponentComponent implements OnInit {
  rate:RateCard;
  ratecardlist:any;
  constructor(public ratecardservice:RateCardServiceService) { }

  ngOnInit() 
  {
    //this.ratecardservice.showRateCard().subscribe((data)=>{this.ratecardlist=data});
  }

  public Insert(value:RateCard)
  {
    this.ratecardservice.addRateCard(value);
  }
  public Update(value:RateCard)
  {
    this.ratecardservice.updateRateCard(value);
  }
  public ShowRateList()
  {
     this.ratecardservice.showRateCard().subscribe((data)=>{this.ratecardlist=data});
  }

}
