import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import{RateCard} from '../RateCard/RateCardModel/RateCard';
import { from } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class RateCardServiceService {
  Rates;
  ratedata:RateCard;
  constructor(public http:HttpClient) 
  { 

  }

  addRateCard(ratecarddata:RateCard)
  {
    console.log(ratecarddata.RateId);
    console.log(ratecarddata.KmStart);
    console.log(ratecarddata.KmEnd);
    console.log(ratecarddata.RideRate);
    this.ratedata=new RateCard();
    this.ratedata.RateId=ratecarddata.RateId;
    this.ratedata.KmStart=ratecarddata.KmStart;
    this.ratedata.KmEnd=ratecarddata.KmEnd;
    this.ratedata.RideRate=ratecarddata.RideRate;

    this.http.post('http://localhost:61786/api/RateCard',this.ratedata)
    .subscribe(res=>(this.Rates=res));
    console.log('going to server');
    
  }
  updateRateCard(ratecarddata:RateCard)
  {
    console.log(ratecarddata.RateId);
    console.log(ratecarddata.KmStart);
    console.log(ratecarddata.KmEnd);
    console.log(ratecarddata.RideRate);
    this.ratedata=new RateCard();
    this.ratedata.RateId=ratecarddata.RateId;
    this.ratedata.KmStart=ratecarddata.KmStart;
    this.ratedata.KmEnd=ratecarddata.KmEnd;
    this.ratedata.RideRate=ratecarddata.RideRate;

    this.http.put('http://localhost:61786/api/RateCard/'+this.ratedata.RateId,this.ratedata)
    .subscribe(res=>(this.Rates=res));
    console.log('going to server');
  }

  showRateCard()
  {
    return this.http.get('http://localhost:61786/api/RateCard');
  }

}
