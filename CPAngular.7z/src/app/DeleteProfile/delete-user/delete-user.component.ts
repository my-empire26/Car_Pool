import { Component, OnInit } from '@angular/core';
import {DeleteUserService} from '../delete-user.service';
import {UserProfile} from '../../UserProfile/UserProfileModel/UserProfile';

@Component({
  selector: 'app-delete-user',
  templateUrl: './delete-user.component.html',
  styleUrls: ['./delete-user.component.css']
})
export class DeleteUserComponent implements OnInit {
  user:UserProfile;
  profiletype:any;
  constructor(public UserServiceService:DeleteUserService) { }

  ngOnInit() {
  }

  public OnDelete(userform:UserProfile)
  {
    console.log(userform.ProfileId);
    this.UserServiceService.deleteUserProfile(userform);
  }


}
