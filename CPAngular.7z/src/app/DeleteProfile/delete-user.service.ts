import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {UserProfile} from '../UserProfile/UserProfileModel/UserProfile';
@Injectable({
  providedIn: 'root'
})
export class DeleteUserService {
  Users;
  udata:UserProfile;
  ProfileId:number;
  constructor(public http:HttpClient) { }

  deleteUserProfile(userdata:UserProfile)
  {
    //this.udata=new UserProfile;
    this.ProfileId=userdata.ProfileId;
    console.log(this.ProfileId);
    this.http.delete('http://localhost:61786/api/UserProfile/'+this.ProfileId)
    .subscribe(res=>{this.Users=res});
  }
}
