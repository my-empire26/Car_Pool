import { Component, OnInit } from '@angular/core';
import {UpdateUserService} from '../update-user.service';
import {UserProfile} from '../../UserProfile/UserProfileModel/UserProfile';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {
  user:UserProfile;
  profiletype:any;
  constructor(public UserServiceService:UpdateUserService) { }

  ngOnInit() {
  }

  public OnUpdate(value:UserProfile)
  {
    this.UserServiceService.updateUserProfile(value);
  }

}
