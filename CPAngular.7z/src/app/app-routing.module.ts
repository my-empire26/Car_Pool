import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LocationComponentComponent} from './Location/location-component/location-component.component';
import {UserProfileComponentComponent} from './UserProfile/user-profile-component/user-profile-component.component';
import {RateCardComponentComponent} from './RateCard/rate-card-component/rate-card-component.component';
import{LoginComponent} from './UserLogin/login/login.component';
import {WalletComponent} from './UserWallet/wallet/wallet.component';
import {RegisterUserComponent} from './UserRegistration/register-user/register-user.component';
import {RideBookingComponent} from './Booking/ride-booking/ride-booking.component';
import {DashboardComponent} from './CPDashboard/dashboard/dashboard.component';
import {DeleteUserComponent} from './DeleteProfile/delete-user/delete-user.component';
import {UpdateUserComponent} from './UpdateProfile/update-user/update-user.component'; 
import {AdminComponent} from './admin/admin.component';
import {AdmindashboardComponent  } from './admindashboard/admindashboard.component';


const routes: Routes = [
    {path:'',redirectTo:'user-login-component',pathMatch:'full'},
    {path:'user-login-component',component:LoginComponent},
    {path:'register-user',component:RegisterUserComponent},
    {path:'user-profile-component',component:UserProfileComponentComponent},
    {path:'location-component',component:LocationComponentComponent},
   {path:'rate-card-component',component:RateCardComponentComponent},
   {path:'wallet',component:WalletComponent},
   {path:'ride-booking',component:RideBookingComponent},
   {path:'dashboard',component:DashboardComponent},
   {path:'delete-user',component:DeleteUserComponent},
   {path:'update-user',component:UpdateUserComponent},
   {path:'admin',component:AdminComponent},
   {path:'admindashboard',component:AdmindashboardComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }