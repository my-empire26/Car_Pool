import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserProfile } from '../../UserProfile/UserProfileModel/UserProfile';
import { LoginService } from '../login.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginform: FormGroup;
  user: UserProfile;
  udatalist: any;
  private myBooleanVal: Boolean;

  constructor(public lservice: LoginService) {
    this.loginform = new FormGroup({
      ContactNumber: new FormControl('', Validators.required),
      pwd: new FormControl('', Validators.required),
    });
  }
  get f() {
    return this.loginform.controls;
  }

  getBooleanValue() {
    this.lservice.getBoolean().subscribe(x => {
      this.myBooleanVal = x;
      console.log(x, "X Value");// this print true "X Value"
      console.log(this.myBooleanVal);// this prints "true"
    });
  }

  save() {
    console.log(this.loginform);
    if (this.loginform.valid) {
      console.log('Saved: ' + JSON.stringify(this.loginform.value));
    }
  }

  ngOnInit() {
    this.user = new UserProfile();
  }
  public onClick(phno: number, pwd: string) {
    this.udatalist = this.lservice.checkUser(phno, pwd);
  }

}
