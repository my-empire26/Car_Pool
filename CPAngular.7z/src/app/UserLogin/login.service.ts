import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable} from 'rxjs';
import {UserProfile} from '../UserProfile/UserProfileModel/UserProfile';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  user:UserProfile;
  status:Boolean;
  statusType:Observable<Boolean>;

  constructor(public http:HttpClient) { }
 
  getBoolean():Observable<Boolean>{

this.http.get<Boolean>("http://localhost:61786//api/UserProfile/geta?phno="+this.user.ContactNumber+"&pwd="+this.user.Password)
    .subscribe((res)=>{
      this.status = res;
      console.log(this.status);
      
      
      if(this.status){
        window.location.assign("/user-profile-component");
      }else{
        alert("Wrong");
      }


    });
    
   
 return this.statusType;
  }

  checkUser(phno:number,pwd:string):Boolean
  {
    this.user=new UserProfile();
    this.user.ContactNumber=phno;
    this.user.Password=pwd;
     console.log(this.user.ContactNumber);
   console.log(this.user.Password);
   
    
    this.statusType=this.getBoolean()
 

   return this.status;
    
  }

}
